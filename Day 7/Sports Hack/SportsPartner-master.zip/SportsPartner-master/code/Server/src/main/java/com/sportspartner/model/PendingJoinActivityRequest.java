package com.sportspartner.model;

public class PendingJoinActivityRequest {
    private String activityId;
    private String requestorId;
    private String creatorId;

    public PendingJoinActivityRequest(){}

    public PendingJoinActivityRequest(String activityId, String requestorId, String creatorId) {
        this.activityId = activityId;
        this.requestorId = requestorId;
        this.creatorId = creatorId;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getRequestorId() {
        return requestorId;
    }

    public void setRequestorId(String requestorId) {
        this.requestorId = requestorId;
    }

    public String getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }
}
