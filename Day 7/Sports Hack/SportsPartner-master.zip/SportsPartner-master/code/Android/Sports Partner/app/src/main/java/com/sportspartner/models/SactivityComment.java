package com.sportspartner.models;

/**
 * Created by yujiaxiao on 11/7/17.
 */

public class SactivityComment {
}
