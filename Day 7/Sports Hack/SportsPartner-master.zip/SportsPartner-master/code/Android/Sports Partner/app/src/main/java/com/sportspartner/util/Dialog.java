package com.sportspartner.util;

import android.support.v4.app.DialogFragment;

/**
 * Created by yujiaxiao on 11/14/17.
 */

public class Dialog extends DialogFragment {

}
