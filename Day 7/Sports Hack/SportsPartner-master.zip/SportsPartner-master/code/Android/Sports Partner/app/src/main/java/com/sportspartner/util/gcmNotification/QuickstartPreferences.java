package com.sportspartner.util.gcmNotification;

/**
 * Created by yujiaxiao on 11/4/17.
 */

public class QuickstartPreferences {
    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
}
