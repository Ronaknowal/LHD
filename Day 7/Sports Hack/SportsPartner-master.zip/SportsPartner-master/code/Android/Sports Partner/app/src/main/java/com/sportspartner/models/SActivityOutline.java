package com.sportspartner.models;


import java.util.Date;
import java.util.List;
import 	java.util.GregorianCalendar;

/**
 * Created by yujiaxiao on 10/21/17.
 */

public class SActivityOutline {
    private String activityId;
    private String creatorId;
    private String status;
    private String sportIconUUID;
    private String sportName;
    private Date startTime;
    private Date endTime;
    private String facilityId;
    private double longitude;
    private double latitude;
    private String address;
    private int capacity;
    private int size;

    public SActivityOutline(){}

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSportIconUUID() {
        return sportIconUUID;
    }

    public void setSportIconUUID(String sportIconUUID) {
        this.sportIconUUID = sportIconUUID;
    }

    public String getSportName() {
        return sportName;
    }

    public void setSportName(String sportName) {
        this.sportName = sportName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "SActivityOutline{" +
                "activityId='" + activityId + '\'' +
                ", creatorId='" + creatorId + '\'' +
                ", status='" + status + '\'' +
                ", sportIconUUID='" + sportIconUUID + '\'' +
                ", sportName='" + sportName + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", facilityId='" + facilityId + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", address='" + address + '\'' +
                ", capacity=" + capacity +
                ", size=" + size +
                '}';
    }
}
